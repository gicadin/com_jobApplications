<?php

defined('_JEXEC') or die('Restricted access');
include_once('jobApplications.php');

?>
