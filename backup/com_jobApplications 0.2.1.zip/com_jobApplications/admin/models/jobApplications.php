<?php
/**
 * jobApplications model
 *
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
/**
 * jobApplications Model
 *
 * @since  0.0.2
 */
class jobApplicationsModeljobApplications extends JModelList
{
	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @return      string  An SQL query
	 */

	protected $mesages;

	public function getTable($type = 'jobApplications', $prefix = 'jobApplicationsTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	public function getMsg($id = 1)
	{
		if (!is_array($this->messages))
		{
			$this->messages = array();
		}

		if (!isset($this->messages[$id]))
		{
			// Request the selected id
			$jinput = JFactory::getApplication()->input;
			$id 	= $jinput->get('id', 1, 'INT');

			// Get a table instance
			$table = $this->getTable();

			// Load the message
			$table->load($id);

			// assign the mgs
			$this->messages[$id] = $table->fname;	
		}

		return $this->messages[$id];

	}

	protected function getListQuery()
	{
		/*
		// Initialize variables.
		$db    = JFactory::getDbo();
		$query = $db->getQuery(true);
 
		// Create the base select statement.
		$query->select('*')->from($db->quoteName('#__helloworld'));
 
		return $query;
		*/
	}
}