<?php
/**
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
/**
 * General Controller of HelloWorld component
 */
class jobApplicationsController extends JControllerLegacy
{
	/**
	 * The default view for the display method.
	 */
	protected $default_view = 'jobApplications';
}