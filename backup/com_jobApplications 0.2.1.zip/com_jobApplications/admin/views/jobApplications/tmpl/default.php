<?php
/**
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<h1> MUIE </h1>
<?php
	$link = JRoute::_('index.php?option=com_jobApplications&task=jobAppications.edit&id=' . $row->id);
	echo JHtml::_('form.token');
?>